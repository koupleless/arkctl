---
name: Feature Request
about: Propose a feature on improving user experience or bringing a new functionality.

---


### Feature description

Describe the feature details with Chinese or English.



### Additional notes

Add other notes if necessary.
